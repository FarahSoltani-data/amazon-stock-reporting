import pandas as pd  # Import pandas

def clean_data(df):
    df.columns = df.columns.str.lower().str.strip()  # Clean column names
    df['date'] = pd.to_datetime(df['date'])  # Convert 'date' column to datetime
    df = df.dropna()  # Drop rows with missing values
    return df

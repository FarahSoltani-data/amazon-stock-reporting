# scripts/send_report.py
import yagmail

def send_email():
    yag = yagmail.SMTP("your_email@gmail.com", "your_password")
    yag.send(
        to="recipient@gmail.com",
        subject="📈 Rapport Amazon",
        contents="Voici le rapport avec les indicateurs calculés.",
        attachments=["output/rapport_amazon.xlsx", "output/stock_chart.png"]
    )

# scripts/extract_data.py
import pandas as pd

def load_data():
    return pd.read_csv("AMZN_2012-05-19_2025-04-06.csv")

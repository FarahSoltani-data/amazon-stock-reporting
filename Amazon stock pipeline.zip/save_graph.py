import os
import matplotlib.pyplot as plt

def save_graph(df):
    try:
        # Ensure the 'output' directory exists
        output_dir = 'output'
        if not os.path.exists(output_dir):
            os.makedirs(output_dir)  # Create the directory if it doesn't exist

        # Plot the graph
        plt.figure(figsize=(10, 6))
        plt.plot(df['date'], df['kpi_value'], label='KPI over Time')
        plt.xlabel('Date')
        plt.ylabel('KPI Value')
        plt.title('KPI Trend')
        plt.legend()

        # Save the graph as a PNG file in the 'output' directory
        plt.savefig(os.path.join(output_dir, 'stock_chart.png'))  # Save to 'output/stock_chart.png'
        plt.close()  # Close the plot to avoid memory issues

        print("Graph saved successfully!")

    except Exception as e:
        print(f"Error while saving graph: {e}")


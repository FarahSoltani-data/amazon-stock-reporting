import os
import matplotlib.pyplot as plt

def save_graph(df):
    try:
        # Define the directory path where you want to save the graph
        output_dir = 'output'

        # Get the current working directory
        current_working_directory = os.getcwd()
        print(f"Current working directory: {current_working_directory}")

        # Check if the 'output' directory exists, and if not, create it
        if not os.path.exists(output_dir):
            print(f"Creating directory: {output_dir}")
            os.makedirs(output_dir)  # This will create the directory
        else:
            print(f"Directory {output_dir} already exists.")

        # Plot the graph
        plt.figure(figsize=(10, 6))
        plt.plot(df['date'], df['kpi_value'], label='KPI over Time')
        plt.xlabel('Date')
        plt.ylabel('KPI Value')
        plt.title('KPI Trend')
        plt.legend()

        # Save the graph as a PNG file in the 'output' directory
        file_path = os.path.join(output_dir, 'stock_chart.png')
        print(f"Saving graph to: {file_path}")

        plt.savefig(file_path)  # Save to 'output/stock_chart.png'
        plt.close()  # Close the plot to avoid memory issues

        print("Graph saved successfully!")

    except Exception as e:
        print(f"Error while saving graph: {e}")

# Example usage:
if __name__ == "__main__":
    import pandas as pd

    # Example dummy data
    data = {
        'date': pd.date_range(start='2025-01-01', periods=10, freq='D'),
        'kpi_value': [100, 200, 150, 300, 250, 350, 400, 450, 500, 550]
    }

    df = pd.DataFrame(data)

    # Call save_graph with the DataFrame
    save_graph(df)

import pandas as pd

def export_excel(df):
    df.to_excel('processed_data.xlsx', index=False)  # Export the dataframe to an Excel file

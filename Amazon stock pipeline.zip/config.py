from dotenv import load_dotenv
import os

load_dotenv()

# Email configuration
EMAIL_SENDER = "your_email@example.com"
EMAIL_RECEIVER = "recipient@example.com"
SMTP_SERVER = "smtp.example.com"
SMTP_PORT = 587
EMAIL_PASSWORD = os.getenv("EMAIL_PASSWORD")


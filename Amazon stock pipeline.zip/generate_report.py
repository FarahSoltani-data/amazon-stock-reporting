# scripts/generate_report.py
import matplotlib.pyplot as plt

def save_graph(df):
    df.plot(x='date', y='close')
    plt.title('Amazon Stock Price')
    plt.tight_layout()
    plt.savefig("output/stock_chart.png")

def export_excel(df):
    df.to_excel("output/rapport_amazon.xlsx", index=False)
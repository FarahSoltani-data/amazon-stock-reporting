# scripts/compute_kpis.py
def compute_kpis(df):
    df['ma30'] = df['close'].rolling(window=30).mean()
    df['ma90'] = df['close'].rolling(window=90).mean()
    return df
